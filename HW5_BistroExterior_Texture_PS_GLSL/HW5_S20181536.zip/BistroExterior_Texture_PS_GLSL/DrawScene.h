﻿//
//  DrawScene.h
//
//  Written for CSE4170
//  Department of Computer Science and Engineering
//  Copyright © 2022 Sogang University. All rights reserved.
//

#pragma once

void drawScene(int argc, char* argv[]);